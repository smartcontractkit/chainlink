module.exports = {
  istanbulReporter: ['lcovonly'],
};
