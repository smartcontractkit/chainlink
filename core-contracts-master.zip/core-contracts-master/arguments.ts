module.exports = [];

// npx hardhat verify --network mainnet --constructor-args arguments.ts <address> --contract "contracts/<name>.sol:<name>"
